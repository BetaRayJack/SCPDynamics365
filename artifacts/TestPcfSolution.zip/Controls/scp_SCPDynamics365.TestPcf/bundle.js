/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./TestPcf/index.ts"
/*!**************************!*\
  !*** ./TestPcf/index.ts ***!
  \**************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   TestPcf: () => (/* binding */ TestPcf)\n/* harmony export */ });\nclass TestPcf {\n  constructor() {\n    this.currentIndex = 0;\n    this.levels = [\"Safe\", \"Euclid\", \"Keter\", \"Taumiel\", \"Apoyllon\"];\n    this.levelColors = [\"#2e7d32\", \"#f9a825\", \"#c62828\", \"#1565c0\", \"#c62828\"];\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this.notifyOutputChanged = notifyOutputChanged;\n    this.container = container;\n    this.container.style.display = \"flex\";\n    this.container.style.flexDirection = \"column\";\n    this.container.style.gap = \"10px\";\n    this.container.style.padding = \"6px 2px\";\n    this.titleElement = document.createElement(\"div\");\n    this.titleElement.textContent = \"SCP Volume Control v1.0.2\";\n    this.titleElement.style.fontFamily = \"Segoe UI, sans-serif\";\n    this.titleElement.style.fontSize = \"12px\";\n    this.titleElement.style.fontWeight = \"700\";\n    this.titleElement.style.letterSpacing = \"0.3px\";\n    this.titleElement.style.textTransform = \"uppercase\";\n    this.titleElement.style.color = \"#666\";\n    this.valueElement = document.createElement(\"div\");\n    this.valueElement.style.fontFamily = \"Segoe UI, sans-serif\";\n    this.valueElement.style.fontSize = \"14px\";\n    this.valueElement.style.fontWeight = \"600\";\n    this.valueElement.style.color = \"#1f1f1f\";\n    this.sliderElement = document.createElement(\"input\");\n    this.sliderElement.type = \"range\";\n    this.sliderElement.min = \"0\";\n    this.sliderElement.max = String(this.levels.length - 1);\n    this.sliderElement.step = \"1\";\n    this.sliderElement.style.width = \"100%\";\n    this.sliderElement.style.margin = \"0\";\n    this.sliderElement.style.accentColor = this.levelColors[0];\n    this.labelsElement = document.createElement(\"div\");\n    this.labelsElement.style.display = \"grid\";\n    this.labelsElement.style.gridTemplateColumns = \"repeat(\".concat(this.levels.length, \", 1fr)\");\n    this.labelsElement.style.gap = \"6px\";\n    this.labelsElement.style.fontFamily = \"Segoe UI, sans-serif\";\n    this.labelsElement.style.fontSize = \"11px\";\n    this.labelsElement.style.color = \"#4d4d4d\";\n    this.levels.forEach(level => {\n      var label = document.createElement(\"div\");\n      label.textContent = level;\n      label.style.textAlign = \"center\";\n      label.style.userSelect = \"none\";\n      this.labelsElement.appendChild(label);\n    });\n    this.sliderElement.addEventListener(\"input\", () => {\n      this.currentIndex = Number(this.sliderElement.value);\n      this.updateDisplay();\n      this.notifyOutputChanged();\n    });\n    container.appendChild(this.titleElement);\n    container.appendChild(this.valueElement);\n    container.appendChild(this.sliderElement);\n    container.appendChild(this.labelsElement);\n    this.updateView(context);\n  }\n  updateView(context) {\n    var _a;\n    var boundValue = (_a = context.parameters.value.raw) !== null && _a !== void 0 ? _a : \"Safe\";\n    var normalizedIndex = this.getLevelIndex(boundValue);\n    this.currentIndex = normalizedIndex;\n    this.sliderElement.value = String(normalizedIndex);\n    this.sliderElement.disabled = context.mode.isControlDisabled;\n    this.updateDisplay();\n  }\n  getOutputs() {\n    return {\n      value: this.levels[this.currentIndex]\n    };\n  }\n  destroy() {\n    var _a, _b, _c, _d;\n    (_a = this.titleElement) === null || _a === void 0 ? void 0 : _a.remove();\n    (_b = this.sliderElement) === null || _b === void 0 ? void 0 : _b.remove();\n    (_c = this.labelsElement) === null || _c === void 0 ? void 0 : _c.remove();\n    (_d = this.valueElement) === null || _d === void 0 ? void 0 : _d.remove();\n  }\n  getLevelIndex(value) {\n    var normalized = value.trim().toLowerCase();\n    var index = this.levels.findIndex(level => level.toLowerCase() === normalized);\n    return index >= 0 ? index : 0;\n  }\n  updateDisplay() {\n    var level = this.levels[this.currentIndex];\n    var color = this.levelColors[this.currentIndex];\n    var progress = this.currentIndex / (this.levels.length - 1) * 100;\n    this.valueElement.textContent = \"Nivel actual: \".concat(level);\n    this.valueElement.style.color = color;\n    this.sliderElement.style.accentColor = color;\n    this.sliderElement.style.background = \"linear-gradient(90deg, \".concat(color, \" 0%, \").concat(color, \" \").concat(progress, \"%, #d9d9d9 \").concat(progress, \"%, #d9d9d9 100%)\");\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./TestPcf/index.ts?\n}");

/***/ }

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./TestPcf/index.ts"](0,__webpack_exports__,__webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('SCPDynamics365.TestPcf', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TestPcf);
} else {
	var SCPDynamics365 = SCPDynamics365 || {};
	SCPDynamics365.TestPcf = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.TestPcf;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}